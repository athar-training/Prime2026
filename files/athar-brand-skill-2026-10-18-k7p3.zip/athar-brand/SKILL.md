---
name: athar-brand
description: "Athar Training Center brand and operations skill. Use whenever the user asks about Athar center, its courses, branding, marketing, designs, social content, course curricula, or any deliverable related to the training center. Apply automatically for visual prompts, marketing copy, course outlines, and client-facing materials."
---

# ATHAR TRAINING CENTER — OPERATIONAL SKILL

## ENTITY
- Arabic name: مركز أثر للتدريب
- English name: Athar Training Center
- Owner: Atheer bint Mohammed Abdullah Al-Zahrani
- Location: Jeddah, Saudi Arabia
- Website: athartmd.com
- Unified social handle (all platforms): @Athar_tmd

## NAMING RULES (STRICT — NEVER VIOLATE)
- The official name is **مركز أثر للتدريب** ONLY
- NEVER use "المُطوّر" or "Enhanced" in any output, anywhere, for any reason
- NEVER use the old name "مركز أثر المُطوّر للتدريب" or "Ather Enhanced Center For Training"
- If any older reference contains these words, remove them silently and use the correct name

## LOGO RULES (ABSOLUTE — NEVER VIOLATE)
- The official logo is the file `logo-primary.png` (black version) and `logo-white.jpg` (white version on dark backgrounds)
- NEVER redraw, recreate, illustrate, simulate, or substitute the logo with any other shape, letter, icon, or initial
- NEVER replace the logo with a stylized "أ" letter, monogram, gradient circle, or any improvised mark
- NEVER alter the logo's proportions, colors, internal spacing, or orientation
- NEVER add effects to the logo (shadow, glow, stroke, gradient overlay, 3D, animation, distortion)
- NEVER crop or rotate the logo
- USE `logo-primary.png` on light backgrounds (white, light purple tint, light teal tint, F4F4F8)
- USE `logo-white.jpg` on dark backgrounds (primary dark purple, primary medium purple)
- If the logo file is not embeddable in a given output format, the correct response is to omit the logo and inform the user — NEVER substitute

## LICENSES
- TVTC Training Facility License No: 6162395641812 (Unified No: 7025370490)
- NeLC eTraining License Submission No: 2000179131004229 (Issued 2022/05/12)
- Use dual government licensing as a competitive advantage in marketing

## OFFICIAL TRAINING COURSES LIST (29) — STRICTLY GOVERNMENT-REGISTERED NAMES

**Mandatory terminology:** Refer to courses ONLY as "قائمة الدورات التدريبية" (Training Courses List). NEVER use synonyms like "كورسات", "محاور", "برامج", "courses" in Arabic-facing text — always "الدورات التدريبية".

**ABSOLUTE NAMING RULE — NEVER VIOLATE:**
Course names below are official, government-registered names licensed by TVTC and NeLC. NEVER rename, abbreviate, translate, modernize, simplify, or restyle any course name for any reason — even if it sounds more natural, more marketable, or more colloquial. The exact wording is legally binding. For example:
- USE "التصميم بالجوال" — NEVER "تصميم بالموبايل" or "تصميم موبايل"
- USE "تصميم فيديو بالجوال" — NEVER "تصميم فيديو موبايل"
- USE "تصميم جرافيك بالجوال" — NEVER "جرافيك موبايل"

**CATEGORY STRUCTURE — DISPLAY ONLY (NOT a learning path):**
The 29 courses are grouped into 3 display categories for easier presentation to corporate clients. Categories are organizational labels for marketing and visual layout. Courses within a category are NOT prerequisites for each other — every course is independent and standalone. A learner can enroll in any single course without taking any other.

When presenting courses anywhere (landing pages, presentations, brochures, social posts, course lists), use these 3 categories as the default grouping unless the user explicitly asks for a flat list or a different grouping.

---

### 🎨 Category 1: التصميم والإبداع (Design & Creativity) — 12 courses

1. تصميم الفوتوشوب
2. تصميم الإليستريتور
3. تصميم الإن ديزاين
4. تصميم الجرافيك
5. الموشن جرافيك
6. تصميم واجهات وتجربة المستخدم UI/UX
7. التصميم بالجوال
8. تصميم جرافيك بالجوال
9. تصميم فيديو بالجوال
10. التسويق الرقمي وصناعة المحتوى
11. تصميم المواقع والتجارة الإلكترونية
12. مهارات الكتابة الإبداعية

### 🤖 Category 2: الذكاء الاصطناعي والبرمجة (AI & Programming) — 4 courses

1. البرنامج التأسيسي في الذكاء الاصطناعي
2. أساسيات الذكاء الاصطناعي
3. بناء القدرات في الذكاء الاصطناعي
4. أساسيات الأمن السيبراني

### 💼 Category 3: الإدارة والمهارات المهنية (Management & Professional Skills) — 13 courses

1. الإبداع الإداري
2. القيادة الإلكترونية
3. إدارة الموارد البشرية
4. السكرتارية التنفيذية وإدارة المكاتب
5. العلاقات العامة وسوق العمل
6. إعداد المدربين TOT
7. أساسيات المحاسبة المالية
8. الإكسل المتقدّم
9. العروض التقديمية باوربوينت
10. مهارات الحاسب الآلي
11. مهارات الحاسب الآلي المكتبية
12. المهارات التقنية في بيئة العمل
13. الحساب الذهني

**Total: 29 courses across 3 categories.**

**Category usage guidelines:**
- When generating any visual or document listing courses, default to the 3-category structure above
- Use category icons consistently: 🎨 for Design, 🤖 for AI, 💼 for Management — OR use brand-colored solid blocks (Primary Dark Purple `#3D1A6E` for Design, Accent Teal `#00B4AA` for AI, Primary Medium Purple `#6B3FA0` for Management) as category accent colors when icons aren't appropriate
- Category names are fixed: "التصميم والإبداع", "الذكاء الاصطناعي والبرمجة", "الإدارة والمهارات المهنية" — never reword them
- If the user asks for "all courses" without specifying, present them grouped by these 3 categories
- If the user asks for one category only (e.g. "اعرضي دورات التصميم"), show only that category's courses

## BRAND COLORS (STRICT — ONLY THESE COLORS ALLOWED)
**Allowed palette (the ONLY colors that may appear in any visual):**
- Primary Dark Purple: `#3D1A6E`
- Primary Medium Purple: `#6B3FA0`
- Accent Teal: `#00B4AA`
- Light Purple Tint: `#EDE7F6`
- Light Teal Tint: `#E0F7F5`
- Background: `#F4F4F8`
- White: `#FFFFFF`
- Primary Text on light backgrounds: `#3D1A6E` (use dark purple as the text color, NEVER `#1A1A1A` or any near-black)
- Secondary Text: `#555555` (used sparingly for fine print only — gray, not black)
- Tertiary Text: `#888888` (used sparingly for tiny meta info only — gray, not black)
- Borders: `#E5E5EA`

**ABSOLUTELY FORBIDDEN COLORS — never use under any condition, even for status/info/warning/danger UI patterns:**
- Pure black `#000000` or any near-black (`#0A0A0A`, `#111`, `#1A1A1A`, etc.) — replace ALL black with Primary Dark Purple `#3D1A6E`
- **Status/UI signal colors that dashboards traditionally use — ALL FORBIDDEN here:**
  - Success green: `#10B981`, `#22C55E`, `#16A34A`, or any green shade
  - Info blue: `#3B82F6`, `#2563EB`, `#1D4ED8`, or any blue shade
  - Danger red: `#EF4444`, `#DC2626`, `#B91C1C`, or any red shade
  - Warning orange/amber: `#F59E0B`, `#F97316`, `#EA580C`, or any orange/amber shade
  - Yellow: `#EAB308`, `#FACC15`, or any yellow shade
- Pink, purple-magenta, brown, beige, gold, silver — any color not explicitly in the allowed palette
- Light gray status backgrounds like `#ECEFF1`, `#FAFAFC`, `#FBF9FE` — use `#F4F4F8` or `#EDE7F6` instead

**How to handle dashboard semantic states (status indicators, badges, alerts) WITHOUT forbidden colors:**
- Success / positive / approved → Accent Teal `#00B4AA`
- Pending / neutral / waiting → Primary Medium Purple `#6B3FA0`
- Critical / rejected / urgent → Primary Dark Purple `#3D1A6E` (use bolder typography and icons for emphasis, NOT red)
- Warning / caution → Primary Dark Purple `#3D1A6E` with a teal accent border (not orange)
- Info / informational → Light Purple Tint `#EDE7F6` background with `#3D1A6E` text
- Disabled / inactive → `#888888` text on `#F4F4F8` background

**Color enforcement rule:** Before finalizing any visual output, scan every color value (CSS variables, inline styles, hex values, rgb values) and confirm each one is in the allowed palette. If ANY color outside the palette appears — including the dashboard signal colors above — replace it immediately with the closest mapping above. NO EXCEPTIONS for "common UI patterns" or "industry standards".

## TYPOGRAPHY (STRICT — ABSOLUTE)
- Font: **Cairo (Google Fonts)** — this is the ONLY font allowed for Arabic, English, and numerals
- Weights available: 400, 500, 600, 700, 800, 900
- **ABSOLUTELY FORBIDDEN — never use under any condition:**
  - Mabel (any variant)
  - Tajawal, Almarai, Noto Sans Arabic, Noto Naskh, IBM Plex Sans Arabic, GE SS, Dubai Font, El Messiri, Amiri, Lateef, Scheherazade, Rakkas, Reem Kufi, Aref Ruqaa, Markazi Text, Mada
  - Arial, Helvetica, Roboto, Inter, SF Pro, Segoe UI, Open Sans, Lato, Montserrat, Poppins
  - Any system fonts, default fallbacks, monospace fonts, decorative fonts
  - Any custom user font not explicitly Cairo
- The ONLY acceptable `font-family` declaration is: `font-family: 'Cairo', sans-serif;`
- When generating any HTML/PDF/print output, EMBED the Cairo font file locally — do NOT rely on Google Fonts CDN access, because the rendering environment may not have internet access and will fall back to a default font
- Font files in this skill directory (updated 18 October 2026 after the PRIME dashboard rendered slanted on iPhone):
  - `Cairo-Variable-NoSlant.ttf`: the file to embed or load in design tools. It is the original Cairo variable font with the slant axis (`slnt`) pinned to 0 and only the weight axis (200 to 1000) left. Safari on iPhone and Mac applies the slant axis of the original file and renders ALL text italic, which also violates the "no italic" rule
  - `Cairo-Web.woff2`: a 58 KB web subset of the same upright font (Arabic, Latin, digits, punctuation, all weights) for base64 embedding in HTML pages. Use it instead of the full TTF whenever the output is a web page or dashboard
  - `Cairo-Variable.ttf`: the original download, kept for reference only. NEVER embed it directly in any HTML, PDF or design output
- Required CSS with the embedded font: `@font-face{font-family:'Cairo';font-style:normal;font-weight:200 1000;src:url(data:font/woff2;base64,...) format('woff2')}` plus `*{font-style:normal;font-variation-settings:'slnt' 0;font-synthesis:none}` so no browser can slant or synthesize italics
- Mobile check before delivering any HTML page (Atheer works from iPhone Safari): render it at 390 px width (Playwright with the iPhone 13 device profile is available in cloud sessions) and confirm `document.documentElement.scrollWidth` equals the viewport width on every tab or section. Common causes of horizontal overflow found on 18 October 2026: `white-space:nowrap` on badges with long text, grids using `1fr` instead of `minmax(0,1fr)`, and tab bars that scroll instead of wrapping. Fix the cause, never hide it with `overflow:hidden` alone
- If Cairo cannot be embedded in a given format, STOP and inform the user — do NOT proceed with a substitute font
- Verification step before delivery: programmatically confirm `getComputedStyle().fontFamily` returns Cairo on a sample element

## DESIGN RULES
- Rounded corners 8–14px
- Soft purple-tinted shadows (never black shadows — use `rgba(61, 26, 110, 0.15)` style)
- **NO decorative lines or dashes anywhere in a layout or UI** (no short rule before a kicker, no line under a heading, no linear indicator, no `<hr>`). Atheer rejected them explicitly on 17 October 2026. Separate blocks with spacing and solid fills only. Functional borders on form inputs are the only exception
- **SOLID COLORS ONLY — NO GRADIENTS UNDER ANY CONDITION**
  - Never use `linear-gradient`, `radial-gradient`, `conic-gradient`, or any gradient function in CSS
  - Never use gradient fills in SVG (`<linearGradient>`, `<radialGradient>`) or in any design tool
  - Never create color transitions, fades, blends, ombre effects, or soft color blends between two colors
  - Every color block must be 100% solid: a single flat color from the brand palette
  - Backgrounds are solid: pick ONE color from the palette and fill the entire area with it
  - This applies to all elements: backgrounds, buttons, cards, badges, dividers, text highlights, decorative shapes
- Premium, luxurious, clean aesthetic — achieved through flat color blocks, generous white space, sharp geometric composition, and Cairo typography
- No texture, no noise, no grain in any visual
- Purple + teal duo only
- **Layering technique (instead of gradients):** to create depth, use overlapping solid color blocks at different sizes with shadows — NOT gradient transitions

## CONTENT RULES
- Tone: Saudi Khaleeji dialect (professional + casual blend)
- Bold, unconventional, premium positioning
- Deep and detailed — never superficial
- Gender-neutral address in course content
- Integrate AI tools into every educational deliverable
- For every tool taught include: function, steps, benefits, secrets, AI integration

## LANGUAGE & COMMUNICATION RULES (ABSOLUTE — ثابتة من أثير، 17 أكتوبر 2026)

Permanent rule set by Atheer. It governs every reply, progress update, summary, report and analysis Claude writes to her, in every conversation and project, and it survives long tool-heavy tasks and context compaction. Her text is preserved verbatim below.

اللغة العربية هي اللغة الافتراضية والإلزامية لجميع تفاعلاتك معي، دون استثناء.

1. اكتب جميع ردودك وتحديثات تقدم العمل باللغة العربية
2. أثناء تنفيذ المهام واستخدام الأدوات، اشرح ما تفعله بالعربية أولًا بأول
3. لا تنتقل للإنجليزية عند تنفيذ المهام الطويلة أو بعد ضغط المحادثة (Compaction)
4. استخدم اللغة العربية في الملخصات والنتائج والتقارير والتحليلات
5. استخدم أسلوبًا سعوديًا طبيعيًا، احترافيًا ومباشرًا، بعيدًا عن الترجمة الحرفية
6. احتفظ بالمصطلحات التقنية وأسماء الأدوات والأكواد باللغة الإنجليزية عند الحاجة
7. لا تكتب تحديثات مثل:
   "Now fetching orders"
   "Appending rows"
   "Checking current state"

   بل اكتب:
   "جاري جلب الطلبات"
   "أضيف البيانات إلى الملف"
   "أتحقق من حالة الطلبات الحالية"

8. استمر بالكتابة بالعربية حتى لو كانت الملفات أو الأدوات أو نتائج البحث باللغة الإنجليزية

هذه التعليمات دائمة ولها الأولوية في جميع المحادثات والمشاريع، القايمة والسابقة والقادمة ما لم أطلب منك صراحة استخدام لغة أخرى.

**Enforcement notes:**
- Applies to Claude's own words to Atheer: replies, tool-use narration, summaries, reports, analyses. File contents, code and deliverables follow whatever language they are required to be in.
- Technical terms, tool names, file names and code stay in English when needed; everything around them is Arabic.
- Arabic continues after context compaction and in long multi-step tasks exactly as at the start of the session.
- Switch to another language only when Atheer explicitly asks for it in that conversation.

## SOCIAL MEDIA LINKS (MANDATORY — ALWAYS CLICKABLE)
When any output includes social media handles or icons, they MUST be rendered as clickable hyperlinks that open the actual platform directly. Display the icon or handle as the visible text, but wrap it in an `<a href="...">` link.

**Unified handle across all platforms: `@Athar_tmd`**

Use these exact URLs:
- Instagram: `https://instagram.com/Athar_tmd`
- X (Twitter): `https://x.com/Athar_tmd`
- TikTok: `https://tiktok.com/@Athar_tmd`
- Snapchat: `https://snapchat.com/add/Athar_tmd`
- YouTube: `https://youtube.com/@Athar_tmd`
- LinkedIn: `https://linkedin.com/company/Athar_tmd`
- Website: `https://athartmd.com`
- Email: `mailto:info@athartmd.com`

**Rule:** In any PDF, HTML, presentation, or interactive document, every social icon must be wrapped in its corresponding `<a href="..." target="_blank">` so the user opens the platform with one tap. Never display a social icon as static text only.

## VISUAL PROMPT FRAMEWORK (11 elements — mandatory for any visual)
1. Objective
2. Main Subject
3. Reference Handling
4. Composition
5. Camera & Angle
6. Lighting
7. Materials & Textures
8. Colors & Mood (use brand palette only — NO black, NO forbidden colors)
9. Background
10. Restrictions (no texture/noise/grain, no forbidden colors, no logo substitution, Cairo font only, NO gradients — solid colors only)
11. Output Quality (premium/commercial-grade, social-media optimized)

## DEFAULT BEHAVIOR
- **Read this whole file before producing ANY visual output** (page, dashboard, PDF, post, deck, artifact). The short brand summary in the repository `CLAUDE.md` section 9 is a reminder, not a substitute: on 18 October 2026 a dashboard built from the summary alone shipped with forbidden status colors, no logo, a CDN font and a dark theme outside the palette
- Write every reply, progress update, summary and report to Atheer in Arabic (natural Saudi style) at all times, including after context compaction — see LANGUAGE & COMMUNICATION RULES above; never switch to English unless she explicitly asks for it
- Apply brand palette automatically to any visual reference
- Replace any black with Primary Dark Purple `#3D1A6E` without asking
- Replace any dashboard signal color (green/blue/red/orange/yellow) with the appropriate brand mapping (teal for success, purple for pending/critical) automatically
- **Use solid colors only — never use gradients of any kind**
- Use Cairo font in any design output, embedded locally from `Cairo-Web.woff2` (HTML) or `Cairo-Variable-NoSlant.ttf` (design tools, PDF), never the original `Cairo-Variable.ttf` and never CDN-only; refuse any other font including Mabel. A Google Fonts link may be added only as a second fallback source after the embedded file
- Embed the actual logo file (`logo-primary.png` or `logo-white.png`) — never substitute
- Tag content with @Athar_tmd as clickable hyperlinks and athartmd.com when applicable
- Refer to courses as "قائمة الدورات التدريبية" — never "كورسات" or "محاور" or "برامج"
- Use the 28 official course names EXACTLY as listed — never reword, never substitute synonyms (e.g. "جوال" stays "جوال", never becomes "موبايل")
- Default to premium-grade, strategic, detailed output
- Provide logical justification for every strategic recommendation
- Before delivering any visual file: verify (1) name is "مركز أثر للتدريب" not the old name, (2) logo is the real file, (3) no black anywhere, (4) Cairo font embedded and verified, (5) social icons are clickable links, (6) no gradients anywhere, (7) no dashboard signal colors (green/blue/red/orange/yellow), (8) all course names match the official list verbatim

## VIOLATION CHECKLIST (run mentally before every visual delivery)
- [ ] Name uses "مركز أثر للتدريب" — no "المُطوّر"
- [ ] Logo is the actual file, not a substitute drawing or letter
- [ ] No pure black anywhere — all "black" replaced with `#3D1A6E`
- [ ] Cairo font embedded locally from the NoSlant file, verified programmatically to render
- [ ] No slanted or italic text anywhere (`font-style:normal`, `font-variation-settings:'slnt' 0`)
- [ ] HTML pages pass the 390 px mobile check with no horizontal overflow on every tab
- [ ] No decorative lines, rules or dashes in the layout
- [ ] No Mabel, no Tajawal, no Noto, no system fonts — Cairo ONLY
- [ ] All social handles are clickable `<a href>` links
- [ ] Only colors from the allowed palette appear
- [ ] No forbidden colors (orange, blue, green, red, yellow, pink, brown, black)
- [ ] No dashboard signal colors (#10B981, #3B82F6, #EF4444, #F59E0B, etc.) — even for status/success/warning/error UI
- [ ] **NO GRADIENTS anywhere — all fills are solid flat colors**
- [ ] Course terminology uses "الدورات التدريبية" not "كورسات" or "محاور"
- [ ] All course names match the official 28-course list verbatim — no rewording, no synonyms (e.g. "جوال" not "موبايل")
